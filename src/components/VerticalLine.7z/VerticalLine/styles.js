import styled from 'styled-components';

export const LineVertical = styled.div`
	border-left: 2px dashed green;
	height: 100px;
	position: relative;
`;
